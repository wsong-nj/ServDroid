package com.event.wtgStructure;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class WTG {

	private WTGNode launcher;
	private List<WTGNode> allNodes;
	private List<WTGEdge> allEdges;
	
	public WTG() {
		allNodes = new ArrayList<WTGNode>();
		allEdges = new ArrayList<WTGEdge>();
	}
	
	public WTGNode addNode(WTGNode node) {
		if(!this.allNodes.contains(node)) {
			this.allNodes.add(node);
		}
		return this.allNodes.get(this.allNodes.indexOf(node));
	}
	
	public WTGNode addLaunchNode(WTGNode node) {
		WTGNode launcherNode = addNode(node);
		if(launcher == null) {
			launcher = launcherNode;
		}else if(launcher != null && launcher != launcherNode) {
			System.out.println("try to set multiple launchers");
		}
		return launcher;
	}
	
	public WTGNode getLauncherNode() {
		return this.launcher;
	}
	
	public WTGEdge addEdge(WTGEdge newEdge) {
		if(!this.allEdges.contains(newEdge)) {
			this.allEdges.add(newEdge);
			newEdge.getSrcNode().addOutEdge(newEdge);
			newEdge.getTgtNode().addInEdge(newEdge);
			return newEdge;
		}else {
			WTGEdge edge = this.allEdges.get(this.allEdges.indexOf(newEdge));
			edge.addEventSeq(newEdge.getEventSeq());
			return edge;
		}
	}
	
	public Collection<WTGNode> getNodes(){
		return this.allNodes;
	}
	
	public Collection<WTGEdge> getEdges(){
		return this.allEdges;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("launcherActivity: ");
		sb.append(getLauncherNode());
		sb.append("\n");
		for(WTGNode node : allNodes) {
			sb.append("current Node: " + node + "\n");
			sb.append("Number of in edges: " + node.getInEdges().size() + "\n");
			sb.append("Number of out edges: " + node.getOutEdges().size() + "\n");
		}
		
		for(WTGEdge edge : allEdges) {
			sb.append("source activity: " + edge.getSrcNode() + "\n");
			sb.append("target activity: " + edge.getTgtNode() + "\n");
			sb.append("event sequence: " + edge.getEventSeq() + "\n");
		}
		return sb.toString();
	}
	
	
}
