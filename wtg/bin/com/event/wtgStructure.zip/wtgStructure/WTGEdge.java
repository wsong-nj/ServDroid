package com.event.wtgStructure;

import java.util.List;
import java.util.Set;

public class WTGEdge {
	
	private WTGNode srcNode;
	private WTGNode tgtNode;
	private Set<List<String>> eventSeq;
	
	public WTGEdge(WTGNode srcNode, WTGNode tgtNode, Set<List<String>> eventSeq) {
		this.srcNode = srcNode;
		this.tgtNode = tgtNode;
		this.eventSeq = eventSeq;
	}

	public WTGNode getSrcNode() {
		return srcNode;
	}

	public void setSrcNode(WTGNode srcNode) {
		this.srcNode = srcNode;
	}

	public WTGNode getTgtNode() {
		return tgtNode;
	}

	public void setTgtNode(WTGNode tgtNode) {
		this.tgtNode = tgtNode;
	}

	public Set<List<String>> getEventSeq() {
		return eventSeq;
	}
	public String getEventSeqToString() {
		StringBuffer sb=new StringBuffer();
		for(List<String> list:eventSeq) {
			sb.append(list.toString());
		}
		return sb.toString();
	}

	public void setEventSeq(Set<List<String>> eventSeq) {
		this.eventSeq = eventSeq;
	}
	
	public void addEventSeq(Set<List<String>> eventSeq) {
		this.eventSeq.addAll(eventSeq);
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return srcNode.hashCode() + tgtNode.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(!(obj instanceof WTGEdge)) {
			return false;
		}
		WTGEdge another = (WTGEdge) obj;
		return srcNode.equals(another.getSrcNode())
				&& tgtNode.equals(another.getTgtNode());
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("src: ");
		sb.append(srcNode);
		sb.append("\n");
		sb.append("tgt: ");
		sb.append(tgtNode);
		sb.append("\n");
		sb.append("eventSeq: ");
		sb.append("\n");
		for(List<String> seq : getEventSeq()) {
			sb.append("\t");
			sb.append(seq);
			sb.append("\n");
		}
		sb.append("\n");
		return sb.toString();
	}

	

	
}
